-- setup_banco.sql
-- Práticas em Desenvolvimento de Sistemas II — IFSC
-- Rode este script UMA VEZ para preparar o banco da prática.
-- No MySQL Workbench, ou no terminal:  mysql -u root -p < setup_banco.sql

-- 1. cria o banco
CREATE DATABASE IF NOT EXISTS escola CHARACTER SET utf8mb4;

-- 2. cria o usuário que o programa Java vai usar
CREATE USER IF NOT EXISTS 'aluno_cd'@'localhost' IDENTIFIED BY 'aluno_pw';
GRANT ALL PRIVILEGES ON escola.* TO 'aluno_cd'@'localhost';
FLUSH PRIVILEGES;

-- 3. cria a tabela e alguns dados de exemplo
USE escola;
CREATE TABLE IF NOT EXISTS estudante (
    id    INT PRIMARY KEY AUTO_INCREMENT,
    nome  VARCHAR(80) NOT NULL,
    curso VARCHAR(60),
    nota  DECIMAL(4,2)
);

INSERT INTO estudante (nome, curso, nota) VALUES
    ('Ana Souza',   'ADS',   8.5),
    ('Bruno Lima',  'ADS',   7.0),
    ('Carla Nunes', 'Redes', 9.2);

SELECT * FROM estudante;
